package database;

import static org.junit.Assert.*;

import org.junit.Test;

public class SearchDatasTst extends SearchDatas {

	@Test
	public void test1() {
		int id = 0;
				System.out.println("The value is:" + CreateData.getValues().get(id));
		}

}
